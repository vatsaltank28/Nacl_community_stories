"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import Hero3D from "@/components/3d/Hero3D";

export default function Home() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <main className="relative min-h-[200vh]" ref={containerRef}>
      {/* SECTION 1: HERO */}
      <section className="relative h-screen flex flex-col justify-center items-center overflow-hidden">
        <Hero3D />
        
        <motion.div 
          className="relative z-10 text-center flex flex-col items-center px-4"
          style={{ y, opacity }}
        >
          <motion.h1 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="text-6xl md:text-8xl font-bold tracking-tighter mb-6 text-balance mix-blend-difference"
          >
            Find Your People.
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="text-xl md:text-2xl text-additional max-w-2xl text-balance mb-12 mix-blend-difference"
          >
            Curated experiences for movement, creativity, wellness and connection.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="flex flex-col sm:flex-row gap-6"
          >
            <button className="px-8 py-4 bg-accent text-primary font-semibold rounded-full hover:bg-white transition-colors duration-300">
              Explore Events
            </button>
            <button className="px-8 py-4 border border-secondary text-secondary font-semibold rounded-full hover:bg-secondary hover:text-primary transition-colors duration-300">
              Join Community
            </button>
          </motion.div>
        </motion.div>
      </section>

      {/* SECTION 2: IMMERSIVE STORY */}
      <section className="relative min-h-screen bg-primary py-24 flex items-center">
        <div className="max-w-7xl mx-auto px-6 w-full">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {["Movement", "Connection", "Creativity", "Exploration"].map((item, i) => (
              <motion.div
                key={item}
                initial={{ opacity: 0, y: 100 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8, delay: i * 0.2 }}
                className="aspect-[3/4] bg-secondary/5 rounded-2xl border border-secondary/10 flex flex-col items-center justify-center p-8 hover:bg-secondary/10 transition-colors backdrop-blur-sm"
              >
                <h3 className="text-2xl font-bold text-secondary mb-4">{item}</h3>
                <div className="w-12 h-12 rounded-full border border-accent/50 flex items-center justify-center text-accent">
                  ✦
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* SECTION 4: COMMUNITY STATS (Placeholder for now) */}
      <section className="py-24 bg-secondary text-primary">
        <div className="max-w-7xl mx-auto px-6">
           <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
             <div>
               <div className="text-5xl font-bold mb-2">10k+</div>
               <div className="text-sm uppercase tracking-widest">Members</div>
             </div>
             <div>
               <div className="text-5xl font-bold mb-2">500+</div>
               <div className="text-sm uppercase tracking-widest">Events Hosted</div>
             </div>
             <div>
               <div className="text-5xl font-bold mb-2">12</div>
               <div className="text-sm uppercase tracking-widest">Cities Active</div>
             </div>
             <div>
               <div className="text-5xl font-bold mb-2">50k</div>
               <div className="text-sm uppercase tracking-widest">Hours Engaged</div>
             </div>
           </div>
        </div>
      </section>
    </main>
  );
}
