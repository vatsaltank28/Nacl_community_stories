"use client";

import { motion } from "framer-motion";
import { Calendar, MapPin, Users, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import CommunityMatch from "@/components/minigame/CommunityMatch";

const MOCK_EVENT = {
  id: "1", 
  title: "Sunset Yoga Flow", 
  category: "Wellness", 
  date: "Oct 24, 2024",
  time: "6:00 PM - 8:00 PM",
  venue: "Rooftop Garden, Downtown", 
  seats: 5, 
  image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=2000&auto=format&fit=crop",
  description: "Join us for an immersive evening of movement and breathwork under the setting sun. This session is designed to help you reconnect with your body and release the tension of the week. Suitable for all levels.",
  host: {
    name: "Sarah Jenkins",
    role: "Wellness Curator",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop"
  },
  timeline: [
    { time: "6:00 PM", event: "Arrival & Settling In" },
    { time: "6:15 PM", event: "Breathwork Introduction" },
    { time: "6:30 PM", event: "Vinyasa Flow" },
    { time: "7:30 PM", event: "Sound Bath & Integration" },
    { time: "7:45 PM", event: "Community Connection" }
  ]
};

export default function EventDetailPage() {
  const [showGame, setShowGame] = useState(false);

  return (
    <div className="min-h-screen pb-24">
      {/* Hero Image */}
      <div className="relative h-[60vh] w-full">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img 
          src={MOCK_EVENT.image} 
          alt={MOCK_EVENT.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/50 to-transparent" />
        
        <Link href="/events" className="absolute top-32 left-6 z-10 flex items-center gap-2 text-secondary hover:text-accent transition-colors">
          <ArrowLeft size={20} /> Back to Events
        </Link>
      </div>

      {/* Content */}
      <div className="max-w-5xl mx-auto px-6 -mt-32 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-primary/90 backdrop-blur-xl border border-secondary/10 rounded-3xl p-8 md:p-12"
        >
          <div className="flex flex-col md:flex-row gap-12">
            {/* Main Column */}
            <div className="flex-1">
              <div className="inline-block bg-accent/20 text-accent px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider mb-6">
                {MOCK_EVENT.category}
              </div>
              <h1 className="text-5xl font-bold tracking-tighter mb-6">{MOCK_EVENT.title}</h1>
              <p className="text-lg text-additional mb-12 leading-relaxed">
                {MOCK_EVENT.description}
              </p>

              <h3 className="text-2xl font-bold mb-6 border-b border-secondary/10 pb-4">Experience Timeline</h3>
              <div className="space-y-6 mb-12">
                {MOCK_EVENT.timeline.map((item, i) => (
                  <div key={i} className="flex gap-6">
                    <div className="text-accent font-medium w-24 flex-shrink-0">{item.time}</div>
                    <div className="text-secondary">{item.event}</div>
                  </div>
                ))}
              </div>

              <h3 className="text-2xl font-bold mb-6 border-b border-secondary/10 pb-4">Curated By</h3>
              <div className="flex items-center gap-4">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={MOCK_EVENT.host.image} alt={MOCK_EVENT.host.name} className="w-16 h-16 rounded-full object-cover" />
                <div>
                  <div className="font-bold text-lg">{MOCK_EVENT.host.name}</div>
                  <div className="text-additional">{MOCK_EVENT.host.role}</div>
                </div>
              </div>
            </div>

            {/* Sidebar Column */}
            <div className="w-full md:w-80 space-y-8">
              <div className="bg-secondary/5 rounded-2xl p-6 border border-secondary/10">
                <div className="space-y-6 mb-8">
                  <div className="flex items-start gap-4">
                    <Calendar className="text-accent mt-1" size={20} />
                    <div>
                      <div className="font-semibold">{MOCK_EVENT.date}</div>
                      <div className="text-sm text-additional">{MOCK_EVENT.time}</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <MapPin className="text-accent mt-1" size={20} />
                    <div>
                      <div className="font-semibold">{MOCK_EVENT.venue}</div>
                      <div className="text-sm text-additional">View Map</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Users className="text-accent mt-1" size={20} />
                    <div>
                      <div className="font-semibold">{MOCK_EVENT.seats} Spots Remaining</div>
                      <div className="text-sm text-additional">Intimate Setting</div>
                    </div>
                  </div>
                </div>
                
                <button 
                  onClick={() => setShowGame(true)}
                  className="w-full py-4 bg-secondary text-primary font-bold rounded-xl hover:bg-accent hover:text-secondary transition-colors duration-300"
                >
                  Join Experience
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {showGame && (
        <CommunityMatch onClose={() => setShowGame(false)} eventId={MOCK_EVENT.id} />
      )}
    </div>
  );
}
