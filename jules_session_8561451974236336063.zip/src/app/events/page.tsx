"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import Link from "next/link";
import { MapPin, Calendar, Users } from "lucide-react";

const CATEGORIES = ["All", "Movement", "Fitness", "Wellness", "Workshops", "Social", "Creative", "Music", "Outdoor"];

const MOCK_EVENTS = [
  { id: "1", title: "Sunset Yoga Flow", category: "Wellness", date: "Oct 24, 6:00 PM", venue: "Rooftop Garden", seats: 5, image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=1000&auto=format&fit=crop" },
  { id: "2", title: "Creative Coding Workshop", category: "Workshops", date: "Oct 26, 10:00 AM", venue: "The Lab", seats: 12, image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=1000&auto=format&fit=crop" },
  { id: "3", title: "Underground Electronic", category: "Music", date: "Oct 31, 11:00 PM", venue: "Basement Club", seats: 45, image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=1000&auto=format&fit=crop" },
  { id: "4", title: "Morning Run Club", category: "Fitness", date: "Nov 2, 7:00 AM", venue: "Central Park", seats: 20, image: "https://images.unsplash.com/photo-1552674605-171ff3ea36f6?q=80&w=1000&auto=format&fit=crop" },
  { id: "5", title: "Pottery Basics", category: "Creative", date: "Nov 5, 2:00 PM", venue: "Clay Studio", seats: 2, image: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?q=80&w=1000&auto=format&fit=crop" },
];

function EventCard({ event }: { event: { id: string, title: string, category: string, date: string, venue: string, seats: number, image: string } }) {
  return (
    <Link href={`/events/${event.id}`}>
      <motion.div 
        whileHover={{ scale: 1.02, rotateY: 5, rotateX: -5 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
        className="bg-secondary/5 border border-secondary/10 rounded-2xl overflow-hidden cursor-pointer group"
        style={{ perspective: "1000px" }}
      >
        <div className="relative h-64 overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img 
            src={event.image} 
            alt={event.title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute top-4 left-4 bg-primary/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider text-secondary">
            {event.category}
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-2xl font-bold mb-4 group-hover:text-accent transition-colors">{event.title}</h3>
          <div className="space-y-2 text-sm text-additional">
            <div className="flex items-center gap-2">
              <Calendar size={16} /> <span>{event.date}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin size={16} /> <span>{event.venue}</span>
            </div>
            <div className="flex items-center gap-2 text-accent">
              <Users size={16} /> <span>{event.seats} seats remaining</span>
            </div>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}

export default function EventsPage() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredEvents = activeCategory === "All" 
    ? MOCK_EVENTS 
    : MOCK_EVENTS.filter(e => e.category === activeCategory);

  return (
    <div className="min-h-screen pt-32 pb-24 px-6 max-w-7xl mx-auto">
      <div className="mb-16">
        <h1 className="text-6xl font-bold tracking-tighter mb-8">Discover Experiences</h1>
        
        {/* Category Filters */}
        <div className="flex flex-wrap gap-3">
          {CATEGORIES.map(category => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === category 
                  ? "bg-secondary text-primary" 
                  : "bg-secondary/10 text-secondary hover:bg-secondary/20"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Masonry-style Grid */}
      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
      >
        {filteredEvents.map(event => (
          <EventCard key={event.id} event={event} />
        ))}
      </motion.div>
    </div>
  );
}
