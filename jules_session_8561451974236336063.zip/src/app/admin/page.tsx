"use client";

import { useState } from "react";
import { Plus, Users, Calendar as CalendarIcon, Settings, Search } from "lucide-react";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("events");

  return (
    <div className="min-h-screen pt-32 pb-24 px-6 max-w-7xl mx-auto flex flex-col md:flex-row gap-12">
      {/* Sidebar */}
      <div className="w-full md:w-64 space-y-2">
        <h2 className="text-xl font-bold mb-8 px-4 text-secondary">Admin Panel</h2>
        <button 
          onClick={() => setActiveTab("events")}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === "events" ? "bg-secondary text-primary font-semibold" : "text-additional hover:bg-secondary/10"}`}
        >
          <CalendarIcon size={20} /> Events
        </button>
        <button 
          onClick={() => setActiveTab("registrations")}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === "registrations" ? "bg-secondary text-primary font-semibold" : "text-additional hover:bg-secondary/10"}`}
        >
          <Users size={20} /> Registrations
        </button>
        <button 
          onClick={() => setActiveTab("settings")}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === "settings" ? "bg-secondary text-primary font-semibold" : "text-additional hover:bg-secondary/10"}`}
        >
          <Settings size={20} /> Settings
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1">
        {activeTab === "events" && (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <h1 className="text-3xl font-bold text-secondary">Manage Events</h1>
              <button className="flex items-center gap-2 px-4 py-2 bg-accent text-primary font-bold rounded-lg hover:bg-white transition-colors">
                <Plus size={20} /> New Event
              </button>
            </div>

            {/* Search/Filter Bar */}
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-additional" size={20} />
                <input 
                  type="text" 
                  placeholder="Search events..." 
                  className="w-full bg-secondary/5 border border-secondary/20 rounded-xl pl-12 pr-4 py-3 text-secondary focus:outline-none focus:border-accent"
                />
              </div>
            </div>

            {/* Mock Events List */}
            <div className="bg-secondary/5 border border-secondary/10 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-secondary">
                <thead className="bg-secondary/10 text-additional text-sm uppercase">
                  <tr>
                    <th className="px-6 py-4">Event</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Registrations</th>
                    <th className="px-6 py-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-secondary/10">
                  <tr className="hover:bg-secondary/5 transition-colors">
                    <td className="px-6 py-4 font-semibold">Sunset Yoga Flow</td>
                    <td className="px-6 py-4 text-additional">Oct 24, 2024</td>
                    <td className="px-6 py-4"><span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-full text-xs">Active</span></td>
                    <td className="px-6 py-4">45 / 50</td>
                    <td className="px-6 py-4 text-accent hover:text-white cursor-pointer">Edit</td>
                  </tr>
                  <tr className="hover:bg-secondary/5 transition-colors">
                    <td className="px-6 py-4 font-semibold">Creative Coding Workshop</td>
                    <td className="px-6 py-4 text-additional">Oct 26, 2024</td>
                    <td className="px-6 py-4"><span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-full text-xs">Active</span></td>
                    <td className="px-6 py-4">12 / 24</td>
                    <td className="px-6 py-4 text-accent hover:text-white cursor-pointer">Edit</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "registrations" && (
          <div>
            <h1 className="text-3xl font-bold text-secondary mb-8">Registrations & Waitlists</h1>
            <div className="bg-secondary/5 border border-secondary/10 rounded-2xl p-8 text-center text-additional">
              Select an event to view its registrations and manage waitlists.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
