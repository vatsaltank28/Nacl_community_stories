"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Sparkles } from "lucide-react";

const QUESTIONS = [
  {
    id: 1,
    question: "What's your preferred vibe?",
    options: ["High Energy", "Chill & Relaxed", "Deep & Thoughtful", "Spontaneous"]
  },
  {
    id: 2,
    question: "How do you recharge?",
    options: ["In a crowd", "In nature", "Creating something", "Quiet conversation"]
  },
  {
    id: 3,
    question: "What draws you to events?",
    options: ["Learning", "Moving my body", "Meeting new people", "Discovering art"]
  }
];

const ARCHETYPES = [
  { name: "Explorer", desc: "Always seeking the next adventure and new horizons." },
  { name: "Creator", desc: "Bringing ideas to life and inspiring those around you." },
  { name: "Mover", desc: "Connected to the physical world through energy and flow." },
  { name: "Connector", desc: "The glue that brings communities and people together." }
];

export default function CommunityMatch({ onClose }: { onClose: () => void, eventId: string }) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [result, setResult] = useState<{name: string, desc: string} | null>(null);

  const handleAnswer = (option: string) => {
    const newAnswers = [...answers, option];
    setAnswers(newAnswers);

    if (step < QUESTIONS.length - 1) {
      setStep(step + 1);
    } else {
      // Mock generation of archetype
      const randomArchetype = ARCHETYPES[Math.floor(Math.random() * ARCHETYPES.length)];
      setResult(randomArchetype);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-primary/80 backdrop-blur-md"
        onClick={onClose}
      />
      
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="relative bg-primary border border-secondary/20 rounded-3xl w-full max-w-lg p-8 shadow-2xl z-10"
      >
        <button onClick={onClose} className="absolute top-6 right-6 text-additional hover:text-secondary">
          <X size={24} />
        </button>

        {!result ? (
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="mt-4"
            >
              <div className="text-accent font-semibold mb-2">Question {step + 1} of {QUESTIONS.length}</div>
              <h3 className="text-3xl font-bold mb-8">{QUESTIONS[step].question}</h3>
              
              <div className="space-y-3">
                {QUESTIONS[step].options.map((option, i) => (
                  <button
                    key={i}
                    onClick={() => handleAnswer(option)}
                    className="w-full p-4 text-left rounded-xl border border-secondary/10 hover:border-accent hover:bg-accent/5 transition-all"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </motion.div>
          </AnimatePresence>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-8"
          >
            <div className="w-20 h-20 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-6 text-accent">
              <Sparkles size={40} />
            </div>
            <h2 className="text-xl text-additional mb-2">Your Archetype Is</h2>
            <h3 className="text-4xl font-bold mb-4 text-accent">{result.name}</h3>
            <p className="text-secondary mb-8">{result.desc}</p>
            
            <button className="w-full py-4 bg-secondary text-primary font-bold rounded-xl hover:bg-white transition-colors">
              Continue to Registration
            </button>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
