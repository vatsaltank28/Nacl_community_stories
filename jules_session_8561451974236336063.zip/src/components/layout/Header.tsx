"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Menu, User, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 w-full z-50 mix-blend-difference text-secondary p-6">
      <nav className="flex justify-between items-center max-w-7xl mx-auto">
        <Link href="/">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-2xl font-bold tracking-tighter"
          >
            NACL
          </motion.div>
        </Link>
        
        <div className="hidden md:flex gap-8 items-center">
          <Link href="/events" className="hover:text-accent transition-colors">
            Experiences
          </Link>
          <Link href="/community" className="hover:text-accent transition-colors">
            Community
          </Link>
          <button className="flex items-center gap-2 hover:text-accent transition-colors">
            <User size={20} />
            <span>Sign In</span>
          </button>
        </div>

        <button 
          className="md:hidden z-50 relative"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-primary z-40 flex flex-col justify-center items-center text-3xl gap-8"
        >
          <Link href="/events" onClick={() => setIsOpen(false)}>
            Experiences
          </Link>
          <Link href="/community" onClick={() => setIsOpen(false)}>
            Community
          </Link>
          <button onClick={() => setIsOpen(false)}>
            Sign In
          </button>
        </motion.div>
      )}
    </header>
  );
}
