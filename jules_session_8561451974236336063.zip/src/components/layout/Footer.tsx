export default function Footer() {
  return (
    <footer className="py-12 border-t border-additional/20 mt-auto bg-primary text-secondary">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center">
        <div className="text-2xl font-bold tracking-tighter mb-4 md:mb-0">
          NACL
        </div>
        <div className="flex gap-6 text-sm text-additional">
          <a href="#" className="hover:text-accent transition-colors">Instagram</a>
          <a href="#" className="hover:text-accent transition-colors">Twitter</a>
          <a href="#" className="hover:text-accent transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
}
